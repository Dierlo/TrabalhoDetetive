
rootProject.name = "Dierlodetetive"

